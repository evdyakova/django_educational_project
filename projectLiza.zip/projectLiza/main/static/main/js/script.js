function Calc() {
	 var a=+document.getElementById('amount').value

	 document.getElementById('summ').value=a*3500

}

function Calc1() {
	 var a1=+document.getElementById('amount1').value

	 document.getElementById('summ1').value=a1*4090

}

function Calc2() {
	 var a2=+document.getElementById('amount2').value

	 document.getElementById('summ2').value=a2*4780

}

function Calc3() {
	 var a3=+document.getElementById('amount3').value

	 document.getElementById('summ3').value=a3*6980

}

function Calc4() {
	 var a4=+document.getElementById('amount4').value

	 document.getElementById('summ4').value=a4*6500

}

function Calc5() {
	 var a5=+document.getElementById('amount5').value

	 document.getElementById('summ5').value=a5*9080

}

function Calc6() {
	 var a6=+document.getElementById('amount6').value

	 document.getElementById('summ6').value=a6*1850

}

function Calc7() {
	 var a7=+document.getElementById('amount7').value

	 document.getElementById('summ7').value=a7*2750

}

function Calc8() {
	 var a8=+document.getElementById('amount8').value

	 document.getElementById('summ8').value=a8*3190

}

function Calc9() {
	 var a9=+document.getElementById('amount9').value

	 document.getElementById('summ9').value=a9*2250

}

function Calc10() {
	 var a10=+document.getElementById('amount10').value

	 document.getElementById('summ10').value=a10*3740

}

function Calc11() {
	 var a11=+document.getElementById('amount11').value

	 document.getElementById('summ11').value=a11*3210

}