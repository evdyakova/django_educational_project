from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='home'),
    path('adress/', views.adress, name='adress'),
    path('delivery/', views.delivery, name='delivery'),
    path('catalog/', views.catalog, name='catalog'),
    path('about/', views.about, name='about'),
    path('task/', views.task, name='task'),
    path('solution/', views.solution, name='solution'),
]

# path('results/', views.show_results, name='results'),