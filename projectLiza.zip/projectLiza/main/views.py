from django.shortcuts import render, redirect
from .models import TriangleTest



def index(request):
    return render(request, 'main/index.html')

def adress(request):
    return render(request, 'main/adress.html')

def catalog(request):
    return render(request, 'main/catalog.html')

def delivery(request):
    return render(request, 'main/delivery.html')

def about(request):
    info = {
        'I':{
            'me': 'Дьякова Елизавета Владиславовна',
            'mail': 'evdyakova@edu.hse.ru',
            'phone': '89603796011',
            'photo': 'https://sun9-54.userapi.com/impg/yRUnGBpig2-zA1PxjqvqogJqaLb1xKxXvdo4Mw/6cAQnrf47mA.jpg?size=1439x2160&quality=95&sign=8fa62d571354c1e0d3b8cb846b18d294&type=album'
        },
        'program':{
            'name': 'Управление и аналитика в государственном секторе',
            'description': 'Программа готовит лидеров государственного и муниципального управления, аналитиков, владеющих навыками оценки, разработки и реализации программ, проектов с применением цифровых технологий.',
            'director': {
                'd_name': 'Кайсарова Валентина Петровна',
                'd_mail': 'vkaissarova@hse.ru',
                'd_photo': 'https://spb.hse.ru/data/2017/07/13/1170958544/Valentina%20Kaisarova.JPG'
            },
            'manager': {
                'm_name': 'Орешенкова Надежда Эдуардовна',
                'm_mail': 'noreshenkova@hse.ru',
                'm_photo': 'https://www.hse.ru/mirror/org/persons/cimage/135416390'
            }
        },
        'friend1': {
            'f1_name': 'Букина Арина Владимировна',
            'f1_mail': 'avbukina@edu.hse.ru',
            'f1_phone': '89511841387',
            'f1_photo': 'https://sun9-74.userapi.com/impg/k2nzmXQLtuguoHZLc63NYHOimOJEovUhsjtPpA/DPE5skjgNrE.jpg?size=1620x2160&quality=95&sign=9934a1d40755d08eb10ad2a68622f05b&type=album'
        },
        'friend2': {
            'f2_name': 'Гончаренко Анастасия Константиновна',
            'f2_mail': 'akgoncharenko@edu.hse.ru',
            'f2_phone': '89207727211',
            'f2_photo': 'https://sun9-54.userapi.com/impg/0KIrwqrVI7qMt8Dljwfg62u6Jg31TqTtLxwt4Q/dJJ_I_VWVvY.jpg?size=1440x1920&quality=96&sign=f8ea6d36b707259a1ea06eccc8903d8d&type=album'
        },
    }
    return render(request, 'main/about.html', info)

def task(request):
    return render(request, 'main/task.html')

def solution(request):
    print(request.__dir__())
    req = dict(request.GET)
    print(req)
    x = req.get('x')
    y = req.get('y')
    z = req.get('z')
    x = int(x[0])
    y = int(y[0])
    z = int(z[0])
    print(x,y,z)
    if x + y <= z or y + z <= x or x + z <= y:
        a = 'Такого тругольника не существует'
    elif (x * x + y * y == z * z) or (x * x + z * z == y * y) or (z * z + y * y == x * x):
        a = "Данный треугольник существует и является прямоугольным"
    else:
        a = 'Такой треугольник существует'

    context = {'a': a}
    print(a)
    return render(request, 'main/solution.html', context)

# def show_results(request):
#     tests = TriangleTest.objects.all()
#     return render(request, 'projectLiza/main/templates/main/results.html', {'tests': tests})




