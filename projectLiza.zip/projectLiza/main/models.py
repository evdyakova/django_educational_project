from django.db import models

class TriangleTest(models.Model):
    x = models.IntegerField()
    y = models.IntegerField()
    z = models.IntegerField()
    result = models.CharField(max_length=200)
    test_number = models.AutoField(primary_key=True)